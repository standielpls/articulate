import { ElementSaver } from "../Dom/ElementSaver";

const { NoteOperations } = require("../Api/NoteOperations");
const { ElementRetriever } = require("../Dom/ElementRetriever");
export const DomOnLoad = () => {
  let url;

  document.addEventListener("DOMContentLoaded", () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tab) => {
      url = tab[0].url;
      let tabTitle = tab[0].title;

      document.getElementById("app-name").textContent = tabTitle;

      const urlParams = new URLSearchParams(url);
      const ytId = urlParams.get("v");
      const thumbnail = `https://img.youtube.com/vi/${ytId}/maxresdefault.jpg`;

      if (url && url.includes("youtube")) {
        chrome.tabs.executeScript(
          tab.id,
          {
            code:
              "yt = document.querySelector('.video-stream').currentTime; yt;",
          },
          function (data) {
            const sec = Math.floor(data[0]);
            url = `${url}&t=${sec}`;
            var yt = document.createElement("a");
            var linkText = document.createTextNode(url);
            yt.appendChild(linkText);
            yt.setAttribute("href", url);
            yt.classList.add("popup");
            document.getElementById("output").hidden = true;
            document.getElementById("video-link").appendChild(yt);
          }
        );
      } else {
        chrome.tabs.executeScript(
          tab.id,
          {
            code: "window.getSelection().toString();",
          },
          function (selection) {
            if (!selection[0] || selection[0] === "") {
              ElementSaver.SaveOutput("Highlight text for it to appear here!");
            } else {
              ElementSaver.SaveOutput(selection[0]);
            }
          }
        );
      }
    });

    const quoteText = ElementRetriever.GetOutput().textContent;
    const noteText = ElementRetriever.GetNote().value;
    const addNotesButton = ElementRetriever.GetAddNoteButton();
    addNotesButton.addEventListener(
      "click",
      NoteOperations.AddNotes({ quote: quoteText, note: noteText, url })
    );
  });
};
