const { DomOnLoad } = require("./Events/FireEvents");
const { NoteOperations } = require("./Api/NoteOperations");

export const DomOnLoad, NoteOperations;
