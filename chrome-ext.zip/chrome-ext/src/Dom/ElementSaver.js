import { ElementRetriever } from "./ElementRetriever";

export class ElementSaver {
  static SaveOutput(output) {
    ElementRetriever.GetOutput().textContent = output;
  }
  static SaveAddNoteButton(text) {
    ElementRetriever.GetAddNoteButton().textContent = text;
  }
}
