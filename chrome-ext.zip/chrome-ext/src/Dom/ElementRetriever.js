export class ElementRetriever {
  static GetOutput() {
    return document.getElementById("output");
  }
  static GetNote() {
    return document.getElementById("comments");
  }
  static GetAddNoteButton() {
    return document.getElementById("add-notes");
  }
}
