import { ElementSaver } from "../Dom/ElementSaver"

export class NoteOperations {
  async static AddNotes({ quote, note, url }) {
    const originAddress = this.GetIPAddress()
    try {
      await this.PostNote(quote, note, url, originAddress)
    }catch (error) {
      console.log(error)
    }
  }

  async static GetIPAddress() {
    const trace = fetch("https://www.cloudflare.com/cdn-cgi/trace")
    const traceText = await trace.text()
    return traceText.match(/ip=(.+)/)[1];
  }

  async static PostNote(quote, note, url, address) {
    const response = await fetch(
      "https://us-central1-lancelot-274021.cloudfunctions.net/createNote",
      {
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        method: "POST",
        body: JSON.stringify({
          user_id: address,
          comment: quote,
          article: note,
          url: url,
        }),
      }
    )
    if (response.ok) {
      ElementSaver.SaveAddNoteButton('Added!')
    }
  }
}
