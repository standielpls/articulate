const { DomOnLoad } = require("./src/app");

DomOnLoad();
